# core models - shared utilities
